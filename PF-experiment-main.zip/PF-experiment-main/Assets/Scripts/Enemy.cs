﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Enemy : MonoBehaviour {

    public Weapon currentGun;
    public PlayerController playerCtrl;
    public ProxemicsBehavior proxemicsBehavior;
    public Image healthBar;
    public Image trustLevelBar;
    public float maxHealth = 100f;
    public float maxTrustLevel = 100f;
    public Vector2 movementSpeed;
    public Vector2 movementSpeedBase = new Vector2(0.2f , 0.2f);
    public Text currentEmotionText;
    public Image serotoninBar;
    public Image noradrenalineBar;
    public Image dopamineBar;
    public float maxSerotonin = 1f;
    public float maxNoradrenaline = 1f;
    public float maxDopamine = 1f;
    public Text serotoninText;
    public Text noradrenalineText;
    public Text dopamineText;

    [HideInInspector]
    public bool hasBeenShot = false;
    [HideInInspector]
    public float maxWalkingTime = 5f;

    public string enemyNumber;

    string lastMentalState = "Neutral";
    float neutralStateTimer = 0;
    float stoppedStateTimer = 0;
    //float hasBeenShotTimer = 0;
    Vector2 direction;
    string currentState = "neutral";
    //string currentPlayerState = "";
    public bool engagedInAction = false;
    Rigidbody2D enemyBody;
    float prejudiceLevel;
    float serotoninLevel;
    float noradrenalineLevel;
    float dopamineLevel;
    float time = 0;
    int duration = 0;
    int[] durValues = new int[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    string[] currentStates = new string[4] {"", "", "", ""};
    Emotion emotion;
    Culture culture;
    Personality personality;
    Dictionary<string, float> cultureAttrs = new Dictionary<string, float>() {
        { "dignity", 0 },
        { "collectivism", 0 },
        { "wealth", 0 },
        { "politeness", 0 },
        { "rationatity", 0 },
        { "trust_level", 0 },
    };
    float[] emotionBands = new float[4] { 0, 0.2f, 0.5f, 0.7f };
    // string script = "emotioncube";
    // string script = "emotionfuzzy";
    // string script = "fuzzystates";
    string script = "saved_emotioncube";
    // string script = "saved_emotionfuzzy";
    // string script = "emotionextendedcube";
    // string script = "saved_extendedemotioncube";
    // string script = "fuzzyoriginal";
    // string script = "saved_fuzzyoriginal";

    // Use this for initialization
    void Start () {
        duration = durValues[Random.Range(0, durValues.Length)];
        serotoninLevel = Random.Range(0f, 1f);
        noradrenalineLevel = Random.Range(0f, 1f);
        dopamineLevel = Random.Range(0f, 1f);
        GenerateInitialEmotion(serotoninLevel, noradrenalineLevel, dopamineLevel);
        GenerateInitialPersonality();
        GenerateInitialCulture();
        prejudiceLevel = Random.Range(0f, 1f);
        trustLevelBar.fillAmount = 0.5f;
        serotoninBar.fillAmount = serotoninLevel;
        noradrenalineBar.fillAmount = noradrenalineLevel;
        dopamineBar.fillAmount = dopamineLevel;
        serotoninText.text = serotoninLevel.ToString("F1");
        noradrenalineText.text = noradrenalineLevel.ToString("F1");
        dopamineText.text = dopamineLevel.ToString("F1");
        SetRandomDirection();

        // float time = culture.GetTime();
        movementSpeed = movementSpeedBase;

        culture.LoadCultureDict(cultureAttrs);

        currentGun.SetShotBy(enemyNumber);
        enemyBody = GetComponent<Rigidbody2D>();

        string name = emotion.GetName();
        if (script == "emotioncube" || script == "saved_emotioncube" || script == "saved_fuzzyoriginal" || script == "fuzzyoriginal"){
            if (name == "Anger") {
                name = "Anger/Rage";
            }
            else if (name == "Fear") {
                name = "Fear/Terror";
            }
            else if (name == "Disgust") {
                name = "Contempt/Disgust";
            }
            else if (name == "Sadness") {
                name = "Shame/Humiliation";
            }
            else if (name == "Grief") {
                name = "Distress/Anguish";
            }
            else if (name == "Interest") {
                name = "Interest/Excitement";
            }
            else if (name == "Joy") {
                name = "Enjoyment/Joy";
            }
        } 
        currentEmotionText.text = name;
    }

    /// <summary>
    /// Generates the initial RANDOM personality.
    /// </summary>
    void GenerateInitialPersonality() {
        float[] newPersonality = new float[5];

        for (int i = 0; i < newPersonality.Length; i++)
        {
            float rand = Random.Range(0f, 1f) * 10f;
            newPersonality[i] = Mathf.Round(rand) * 0.1f;
            // newPersonality[i] = 0.0f;
        }
        personality = new Personality(newPersonality);
    }

    /// <summary>
    /// Generates RANDOM bios emotion.
    /// </summary>
    void GenerateInitialEmotion(float ser, float nor, float dop) {
        // float[] randomEmotion = Emotion.GetRandomEmotion();
        // float[] newEmotion = new float[4];
        float[] dummyEmo = {0, 0, 0, 0};
        Emotion emo = new Emotion(dummyEmo);

        // for (int i = 0; i < newEmotion.Length; i++)
        // {
        //     // newEmotion[i] = randomEmotion[i];
        //     if (i == newEmotion.Length - 1)
        //         newEmotion[i] = 0.5f;
        //     else
        //         newEmotion[i] = 0;
        // }
        float[] newEmotion;
        if (script == "fuzzystates") {
            string param = ser.ToString("F1") + "," + nor.ToString("F1") + "," + dop.ToString("F1");
            string[] words = emo.GetNextState("first," + param);
            currentStates = new string[4] {words[0], words[1], words[2], words[3]};
            newEmotion = emo.GetEmotionValues(words[4]);
        }
        else {
            newEmotion = emo.GetNeuroResult(ser, nor, dop, script);
        }
        emotion = new Emotion(newEmotion);
        // emotion = new Emotion(dummyEmo);
    }

    // Generating RANDOM culture
    /// <summary>
    /// Generates the RANDOM initial culture.
    /// </summary>
    void GenerateInitialCulture() {
        float[] newCulture = new float[6];

        for (int i = 0; i < newCulture.Length; i++)
        {
            float rand = Random.Range(0f, 1f) * 10f;
            newCulture[i] = Mathf.Round(rand) * 0.1f;
            // newCulture[i] = 0.0f;
        }
        culture = new Culture(newCulture);
    }

    /// <summary>
    /// Sets a random direction.
    /// </summary>
    void SetRandomDirection()
    {
        int dirX = Random.Range(0, 2);
        int dirY = (dirX == 1)? 0 : 1;
        direction = new Vector2(dirX, dirY);
    }

    /// <summary>
    /// Updates the neutral movement.
    /// </summary>
    /// <param name="dt">Delta time.</param>
    void UpdateNeutralMovement(float dt) {
        if (neutralStateTimer > maxWalkingTime) {
            // currentState = "stopped";
            neutralStateTimer = 0;
        }

        Vector2 position = enemyBody.position;


        position.x += direction.x * movementSpeed.x * dt;
        position.y += direction.y * movementSpeed.y * dt;

        if (position.x < -18.2f ) {
            position.x = 18f;
        }
        if (position.x > 18.2f) {
            position.x = -18f;
        }

        if (position.y < -11.2f) {
            position.y = 11f;
        }
        if (position.y > 11.2f) {
            position.y = -11f;
        }
        enemyBody.position = position;

        if (!engagedInAction) {
            neutralStateTimer += dt;
        }
    }

    /// <summary>
    /// Updates the stop action.
    /// </summary>
    /// <param name="dt">Delta time</param>
    void UpdateStopAction(float dt) {
        if (stoppedStateTimer > 7.0f) {
            SetRandomDirection();
            // currentState = "neutral";
            stoppedStateTimer = 0;
        }

        if (!engagedInAction) {
            stoppedStateTimer += dt;
        }
    }

    void UpdateShootRandom() {
        // Vector2 transformPos = transform.position;
        Vector2 shotDirection = new Vector2(Random.Range(-1f, 1f), Random.Range(-1f, 1f));
        shotDirection.Normalize();

        currentGun.SetDirection(shotDirection.x, shotDirection.y);
        currentGun.SetTrigger(true);
    }

    /// <summary>
    /// Updates the shoot player.
    /// </summary>
    void UpdateShootPlayer() {
        Vector2 transformPos = transform.position;
        PlayerController player = proxemicsBehavior.currentPlayer;
        if (player && playerCtrl) {
            Vector2 playerPosition = playerCtrl.GetCurrentPosition();
            Vector2 shotDirection = playerPosition - transformPos;
            shotDirection.Normalize();

            currentGun.SetDirection(shotDirection.x, shotDirection.y);
            currentGun.SetTrigger(true);
        }
        else {
            // currentState = "neutral";
            currentGun.SetTrigger(false);
        }
    }

    /// <summary>
    /// Updates the run away.
    /// </summary>
    void UpdateRunAway(float dt) {
        Vector2 position = enemyBody.position;
        PlayerController player = proxemicsBehavior.currentPlayer;
        // Debug.Log(player);
        // Debug.Log(playerCtrl);
        if (player && playerCtrl) {
            Vector2 target = playerCtrl.GetCurrentPosition();
            target = position + (position - target) * 100;
            enemyBody.position = Vector2.MoveTowards(position, target, dt);
            // Debug.Log("qualquer coisa 2");
        }
        // else {
            // currentState = "neutral";
        // }
    }

    /// <summary>
    /// Updates the follow.
    /// </summary>
    void UpdateFollow(float dt) {
        //Vector2 position = enemyBody.position;
        Vector2 position = transform.position;
        PlayerController player = proxemicsBehavior.currentPlayer;
        // Debug.Log(player);
        // Debug.Log(playerCtrl);
        if (player && playerCtrl) {
            Vector2 target = playerCtrl.GetCurrentPosition();
            // Debug.Log(target);
            enemyBody.position = Vector2.MoveTowards(position, target, dt);
        }
        // else {
            // currentState = "neutral";
        // }
    }

    /// <summary>
    /// Updates enemy behavior.
    /// </summary>
    /// <param name="dt">Delta time.</param>
    void UpdateBehavior(float dt) {
        // if (currentState == "neutral") {
        //     UpdateNeutralMovement(dt);
        // }
        // else if(currentState == "stopped") {
        //     UpdateStopAction(dt);
        // }
        if(script == "emotioncube" || script == "saved_emotioncube" || script == "saved_fuzzyoriginal" || script == "fuzzyoriginal") {
            if(emotion.GetName() != "Surprise") {
                UpdateNeutralMovement(dt);
            }
            if(emotion.GetName() == "Anger") {
                // UpdateShootRandom();
                UpdateFollow(dt);
                UpdateShootPlayer();
                movementSpeed = movementSpeedBase * 2;
            }
            else if(emotion.GetName() == "Grief") {
                UpdateShootPlayer();
                int odds = Random.Range(0, 100);
                if (odds == 1) {
                    UpdateShootRandom();
                }
                movementSpeed = movementSpeedBase * 5;
            }
            else if (emotion.GetName() == "Disgust") {
                // Debug.Log("entrei 1");
                UpdateRunAway(dt);
                movementSpeed = movementSpeedBase;
            }
            else if (emotion.GetName() == "Sadness") {
                UpdateRunAway(dt / 10);
                movementSpeed = movementSpeedBase / 5;
            }
            else if (emotion.GetName() == "Fear") {
                UpdateShootPlayer();
                UpdateRunAway(dt * 3);
                movementSpeed = movementSpeedBase * 3;
            }
            else if (emotion.GetName() == "Joy") {
                // Debug.Log("entrei 2");
                UpdateFollow(dt);
                movementSpeed = movementSpeedBase;
            }
            else if (emotion.GetName() == "Interest") {
                UpdateFollow(dt * 2);
                movementSpeed = movementSpeedBase * 10;
            }
        }
        else {
            if(emotion.GetName() != "Surprise" && emotion.GetName() != "Distraction" && emotion.GetName() != "Amazement"){
                UpdateNeutralMovement(dt);
            }
            if (emotion.GetName() == "Neutral") {
                movementSpeed = movementSpeedBase;
            }
            else if (emotion.GetName() == "Pensiveness") {
                UpdateRunAway(dt / 10);
                movementSpeed = movementSpeedBase / 5;
            }
            else if (emotion.GetName() == "Sadness") {
                UpdateRunAway(dt / 5);
                movementSpeed = movementSpeedBase / 5;
            }
            else if(emotion.GetName() == "Grief") {
                UpdateShootPlayer();
                int odds = Random.Range(0, 100);
                if (odds == 1) {
                    UpdateShootRandom();
                }
                movementSpeed = movementSpeedBase * 5;
            }
            else if (emotion.GetName() == "Boredom") {
                movementSpeed = movementSpeedBase / 5;
            }
            else if (emotion.GetName() == "Disgust") {
                // Debug.Log("entrei 1");
                UpdateRunAway(dt);
                movementSpeed = movementSpeedBase;
            }
            else if (emotion.GetName() == "Loathing") {
                UpdateRunAway(dt * 2);
                movementSpeed = movementSpeedBase * 2;
            }
            if (emotion.GetName() == "Apprehension") {
                UpdateRunAway(dt / 2);
                movementSpeed = movementSpeedBase / 2;
            }
            else if (emotion.GetName() == "Fear") {
                UpdateShootPlayer();
                UpdateRunAway(dt);
                movementSpeed = movementSpeedBase;
            }
            else if (emotion.GetName() == "Terror") {
                UpdateShootPlayer();
                UpdateRunAway(dt * 3);
                movementSpeed = movementSpeedBase * 3;
            }
            else if (emotion.GetName() == "Annoyance") {
                UpdateShootPlayer();
                movementSpeed = movementSpeedBase;
            }
            else if(emotion.GetName() == "Anger") {
                UpdateFollow(dt);
                UpdateShootPlayer();
                movementSpeed = movementSpeedBase;
            }
            else if (emotion.GetName() == "Rage") {
                UpdateFollow(dt);
                UpdateShootPlayer();
                movementSpeed = movementSpeedBase * 2;
            }
            else if (emotion.GetName() == "Serenity") {
                UpdateFollow(dt / 2);
                movementSpeed = movementSpeedBase / 2;
            }
            else if (emotion.GetName() == "Joy") {
                // Debug.Log("entrei 2");
                UpdateFollow(dt);
                movementSpeed = movementSpeedBase;
            }
            else if (emotion.GetName() == "Ecstasy") {
                UpdateFollow(dt * 2);
                movementSpeed = movementSpeedBase * 10;
            }
            else if (emotion.GetName() == "Interest") {
                UpdateFollow(dt);
                movementSpeed = movementSpeedBase;
            }
            else if (emotion.GetName() == "Anticipation") {
                movementSpeed = movementSpeedBase * 5;
            }
            else if (emotion.GetName() == "Vigilance") {
                movementSpeed = movementSpeedBase * 10;
            }
        }
    }

    /// <summary>
    /// Updates the trust level value.
    /// </summary>
    void UpdateTrustLevel() {
        Dictionary<string, int> trustInf = AllEmotions.GetTrustInfluence();
        float trustLvl = trustLevelBar.fillAmount;
        string mentalStateName = emotion.GetMentalStateName();
        //Debug.Log("Mental State: " + mentalStateName);
        int infValue = trustInf[mentalStateName];
        //Debug.Log(infValue);

        trustLvl = trustLvl + infValue * prejudiceLevel * (1 / maxTrustLevel);
        // serLvl = 0;
        trustLevelBar.fillAmount = trustLvl;
    }

    void UpdateCurrentState() {
        // Dictionary<string, int> trustInf = AllEmotions.GetTrustInfluence();
        // string mentalStateName = emotion.GetMentalStateName();

        //if (mentalStateName != lastMentalState) {
        //    emotion.ResetCurrentEmotion();
        //    lastMentalState = mentalStateName;
        //}

        currentState = emotion.GetName().ToLower();
    }

    /// <summary>
    /// Dispatchs the state of the player.
    /// </summary>
    /// <param name="playerState">Player current action state.</param>
    public void DispatchPlayerState(string playerState) {
        Dictionary<string, string[]> stateEmo = ActionEmotions.GetDict();
        Dictionary<string, string> stateAttrs = ActionEmotions.GetCultureAttributes();
        Dictionary<string, float[]> allEmo = AllEmotions.GetDict();

        if (playerState == "is_attacking") {
            // Debug.Log("oi");
            serotoninLevel = serotoninLevel - 0.3f;
            if (serotoninLevel < 0) {
                serotoninLevel = 0;
            }
            noradrenalineLevel = noradrenalineLevel + 0.3f;
            if (noradrenalineLevel > maxNoradrenaline) {
                noradrenalineLevel = maxNoradrenaline;
            }
        }
        if (playerState == "is_shooting") { //inimigos atiram tbm
            // Debug.Log("oi1");
        }
        if (playerState == "is_harming") {
            // Debug.Log("oi2");
        }
        if (playerState == "is_injured") {
            // Debug.Log("oi3");
        }
        if (playerState == "is_personal") {
            // Debug.Log("oi4");
        }
        if (playerState == "is_intimate") {
            // Debug.Log("oi14");
        }
        if (playerState == "is_giving_item") {
            // Debug.Log("oi5");
            dopamineLevel = dopamineLevel + 0.3f;
            if (dopamineLevel > maxDopamine) {
                dopamineLevel = maxDopamine;
            }
            serotoninLevel = serotoninLevel + 0.1f;
            if (serotoninLevel > maxSerotonin) {
                serotoninLevel = maxSerotonin;
            }
        }
        if (playerState == "is_stealing_item") {
            // Debug.Log("oi6");
            dopamineLevel = dopamineLevel - 0.3f;
            if (dopamineLevel < 0) {
                dopamineLevel = 0;
            }
        }
        if (playerState == "is_giving_money") {
            // Debug.Log("oi7");
            noradrenalineLevel = noradrenalineLevel + 0.3f;
            if (noradrenalineLevel > maxNoradrenaline) {
                noradrenalineLevel = maxNoradrenaline;
            }
        }
        if (playerState == "is_stealing_money") {
            // Debug.Log("oi8");
            noradrenalineLevel = noradrenalineLevel - 0.3f;
            if (noradrenalineLevel < 0) {
                noradrenalineLevel = 0;
            }
            serotoninLevel = serotoninLevel + 0.1f;
            if (serotoninLevel > maxSerotonin) {
                serotoninLevel = maxSerotonin;
            }
            dopamineLevel = dopamineLevel + 0.1f;
            if (dopamineLevel > maxDopamine) {
                dopamineLevel = maxDopamine;
            }
        }
        if (playerState == "is_social") {
            // Debug.Log("oi11");
        }
        if (playerState == "is_talking_politely") {
            // Debug.Log("oi12");
            serotoninLevel = serotoninLevel + 0.3f;
            if (serotoninLevel > maxSerotonin) {
                serotoninLevel = maxSerotonin;
            }
            dopamineLevel = dopamineLevel + 0.1f;
            if (dopamineLevel > maxDopamine) {
                dopamineLevel = maxDopamine;
            }
        }
        if (playerState == "is_not_talking_politely") {
            // Debug.Log("oi13");
            serotoninLevel = serotoninLevel - 0.3f;
            if (serotoninLevel < 0) {
                serotoninLevel = 0;
            }
        }
        
        float[] newEmotion = null;
        if (script == "fuzzystates") {
            string[] words = emotion.GetNextState("next," + currentStates[0] + "," + currentStates[1] + "," + currentStates[2] + "," + currentStates[3]);
            currentStates = new string[4] {words[0], words[1], words[2], words[3]};
            newEmotion = emotion.GetEmotionValues(words[4]);
            // string param = serotoninLevel.ToString("F1") + "," + noradrenalineLevel.ToString("F1") + "," + dopamineLevel.ToString("F1");
            // string[] words = emotion.GetNextState("first," + param);
            // currentStates = new string[4] {words[0], words[1], words[2], words[3]};
            // newEmotion = emotion.GetEmotionValues(words[4]);
        }
        else {
            newEmotion = emotion.GetNeuroResult(serotoninLevel, noradrenalineLevel, dopamineLevel, script);
        }
        emotion = new Emotion(newEmotion);
        serotoninBar.fillAmount = serotoninLevel;
        noradrenalineBar.fillAmount = noradrenalineLevel;
        dopamineBar.fillAmount = dopamineLevel;
        serotoninText.text = serotoninLevel.ToString("F1");
        noradrenalineText.text = noradrenalineLevel.ToString("F1");
        dopamineText.text = dopamineLevel.ToString("F1");
        name = emotion.GetName();  
        if (script == "emotioncube" || script == "saved_emotioncube" || script == "saved_fuzzyoriginal" || script == "fuzzyoriginal"){
            if (name == "Anger") {
                name = "Anger/Rage";
            }
            else if (name == "Fear") {
                name = "Fear/Terror";
            }
            else if (name == "Disgust") {
                name = "Contempt/Disgust";
            }
            else if (name == "Sadness") {
                name = "Shame/Humiliation";
            }
            else if (name == "Grief") {
                name = "Distress/Anguish";
            }
            else if (name == "Interest") {
                name = "Interest/Excitement";
            }
            else if (name == "Joy") {
                name = "Enjoyment/Joy";
            }
        } 
        currentEmotionText.text = name;

        // if (playerState != "") {
        //     string[] emotionsArray = stateEmo[playerState];
        //     string attrName = stateAttrs[playerState];
        //     float rat = 1 - culture.GetRationality();
        //     float attrValue = cultureAttrs[attrName];
        //     float result = Mathf.Sqrt(attrValue * rat);
        //     string resEmotion = emotionsArray[0];

        //     for (int i = 1; i < emotionBands.Length; i++)
        //     {
        //         if (result > emotionBands[i])
        //         {
        //             resEmotion = emotionsArray[i];
        //         }
        //     }
            //Debug.Log("Result Emotion: " + resEmotion);

            // UpdateEmotionByEvent(allEmo[resEmotion]);
        //     //string infEmoStr = "Influent Emotion: ";
        //     //float[] infEmo = emotion.GetMostInfluentEmotion();

        //     //for (int i = 0; i < infEmo.Length; i++)
        //     //{
        //     //    infEmoStr += infEmo[i] + ",";
        //     //}
        //     //Debug.Log(infEmoStr);
        //     //Debug.Log("Influent Emotion Name: " + emotion.GetMostInfluentName());
            // UpdateTrustLevel();
            // UpdateCurrentState();
        // }
    }

    // Update is called once per frame
    void Update () {
        float dt = Time.deltaTime;

        // emotion.Update(dt);
        time += dt;
        // if (0 == 1) {
        if (time == -5) {
        // if (time > duration) {
            time = 0;
            duration = durValues[Random.Range(0, durValues.Length)];

            // if (Random.Range(0, 2) == 1) {
            //     if (Random.Range(1, 5) == 1) {
            //         serotoninLevel = serotoninLevel + 0.1f;
            //         noradrenalineLevel = noradrenalineLevel - 0.1f;
            //         dopamineLevel = dopamineLevel - 0.1f;
            //         if (serotoninLevel > maxSerotonin) {
            //             serotoninLevel = serotoninLevel - 0.3f;
            //         }
            //         if (noradrenalineLevel < 0) {
            //             noradrenalineLevel = noradrenalineLevel + 0.3f;
            //         }
            //         if (dopamineLevel < 0) {
            //             dopamineLevel = dopamineLevel + 0.3f;
            //         }
            //     }
            //     else if (Random.Range(1, 5) == 2) {
            //         serotoninLevel = serotoninLevel - 0.1f;
            //         noradrenalineLevel = noradrenalineLevel + 0.1f;
            //         dopamineLevel = dopamineLevel - 0.1f;
            //         if (serotoninLevel < 0) {
            //             serotoninLevel = serotoninLevel + 0.3f;
            //         }
            //         if (noradrenalineLevel > maxNoradrenaline) {
            //             noradrenalineLevel = noradrenalineLevel - 0.3f;
            //         }
            //         if (dopamineLevel < 0) {
            //             dopamineLevel = dopamineLevel + 0.3f;
            //         }
            //     }
            //     else if (Random.Range(1, 5) == 3) {
            //         serotoninLevel = serotoninLevel - 0.1f;
            //         noradrenalineLevel = noradrenalineLevel - 0.1f;
            //         dopamineLevel = dopamineLevel + 0.1f;
            //         if (serotoninLevel < 0) {
            //             serotoninLevel = serotoninLevel + 0.3f;
            //         }
            //         if (noradrenalineLevel < 0) {
            //             noradrenalineLevel = noradrenalineLevel + 0.3f;
            //         }
            //         if (dopamineLevel > maxDopamine) {
            //             dopamineLevel = dopamineLevel - 0.3f;
            //         }
            //     }
            //     else {
            //         serotoninLevel = serotoninLevel + 0.1f;
            //         noradrenalineLevel = noradrenalineLevel + 0.1f;
            //         dopamineLevel = dopamineLevel + 0.1f;
            //         if (serotoninLevel > maxSerotonin) {
            //             serotoninLevel = serotoninLevel - 0.3f;
            //         }
            //         if (noradrenalineLevel > maxNoradrenaline) {
            //             noradrenalineLevel = noradrenalineLevel - 0.3f;
            //         }
            //         if (dopamineLevel > maxDopamine) {
            //             dopamineLevel = dopamineLevel - 0.3f;
            //         }
            //     }
            // }
            // else {
            //     if (Random.Range(1, 4) == 1){
            //         serotoninLevel = serotoninLevel - 0.2f;
            //         if (serotoninLevel < 0) {
            //             serotoninLevel = serotoninLevel + 0.5f;
            //         }
            //     }
            //     else if (Random.Range(1, 4) == 2){
            //         noradrenalineLevel = noradrenalineLevel - 0.2f;
            //         if (noradrenalineLevel < 0) {
            //             noradrenalineLevel = noradrenalineLevel + 0.5f;
            //         }
            //     }
            //     else if (Random.Range(1, 4) == 3){
            //         dopamineLevel = dopamineLevel - 0.2f;
            //         if (dopamineLevel < 0) {
            //             dopamineLevel = dopamineLevel + 0.5f;
            //         }
            //     }
            // }
            float[] newEmotion = null;
            if (script == "fuzzystates") {
                string[] words = emotion.GetNextState("next," + currentStates[0] + "," + currentStates[1] + "," + currentStates[2] + "," + currentStates[3]);
                currentStates = new string[4] {words[0], words[1], words[2], words[3]};
                newEmotion = emotion.GetEmotionValues(words[4]);
                // string param = serotoninLevel.ToString("F1") + "," + noradrenalineLevel.ToString("F1") + "," + dopamineLevel.ToString("F1");
                // string[] words = emotion.GetNextState("first," + param);
                // currentStates = new string[4] {words[0], words[1], words[2], words[3]};
                // newEmotion = emotion.GetEmotionValues(words[4]);
            }
            else {
                newEmotion = emotion.GetNeuroResult(serotoninLevel, noradrenalineLevel, dopamineLevel, script);
            }
            emotion = new Emotion(newEmotion);
            serotoninBar.fillAmount = serotoninLevel;
            noradrenalineBar.fillAmount = noradrenalineLevel;
            dopamineBar.fillAmount = dopamineLevel;
            serotoninText.text = serotoninLevel.ToString("F1");
            noradrenalineText.text = noradrenalineLevel.ToString("F1");
            dopamineText.text = dopamineLevel.ToString("F1");
            name = emotion.GetName();  
            if (script == "emotioncube" || script == "saved_emotioncube" || script == "saved_fuzzyoriginal" || script == "fuzzyoriginal"){
                if (name == "Anger") {
                    name = "Anger/Rage";
                }
                else if (name == "Fear") {
                    name = "Fear/Terror";
                }
                else if (name == "Disgust") {
                    name = "Contempt/Disgust";
                }
                else if (name == "Sadness") {
                    name = "Shame/Humiliation";
                }
                else if (name == "Grief") {
                    name = "Distress/Anguish";
                }
                else if (name == "Interest") {
                    name = "Interest/Excitement";
                }
                else if (name == "Joy") {
                    name = "Enjoyment/Joy";
                }
            } 
            currentEmotionText.text = name;
        }

        UpdateBehavior(dt);

        cultureAttrs["trust_level"] = trustLevelBar.fillAmount;

        if (healthBar.fillAmount <= 0) {
            Destroy(gameObject);
        }

        // currentEmotionText.text = emotion.GetMostInfluentName();
    }

    /// <summary>
    /// Updates the emotion by event.
    /// </summary>
    /// <param name="eventEmotion">Event emotion.</param>
    void UpdateEmotionByEvent(float[] eventEmotion) {
        float[] newEmotion = new float[4];
        float[] p = personality.GetPersonality();
        float[,] pFactors = Personality.PositiveFactors;
        float[,] nFactors = Personality.NegativeFactors;

        // Generate new emotion based on Personality Traits and Factors
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 5; j++) {
                if (eventEmotion[i] > 0)
                    newEmotion[i] += eventEmotion[i] * p[j] * pFactors[j, i];
                else
                    newEmotion[i] += eventEmotion[i] * p[j] * nFactors[j, i];
            }
            newEmotion[i] = newEmotion[i] / 5;
        }

        // Add new generated emotion
        emotion.AddEmotion(newEmotion);
        // Clamp after emotion add
        emotion.ClampCurrentEmotion();
        // Set the most influent emotion
        emotion.SetMostInfluentEmotion();
    }
}