import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl
import random
import sys
import warnings

# Ignore RuntimeWarning
warnings.filterwarnings("ignore", category=RuntimeWarning)

values = sys.argv[1].split(',')
ser_val = float(values[0])
nor_val = float(values[1])
dop_val = float(values[2])

x = np.arange(0, 1, 0.001)
y = np.arange(0, 1, 0.001)
z = np.arange(0, 1, 0.001)
plutchik_range = np.arange(-1, 1, 0.001)

serotonin = ctrl.Antecedent(x, 'serotonin')
noradrenaline = ctrl.Antecedent(y, 'noradrenaline')
dopamine = ctrl.Antecedent(z, 'dopamine')
joy_axis = ctrl.Consequent(plutchik_range, 'joy_axis')
disgust_axis = ctrl.Consequent(plutchik_range, 'disgust_axis')
fear_axis = ctrl.Consequent(plutchik_range, 'fear_axis')
surprise_axis = ctrl.Consequent(plutchik_range, 'surprise_axis')

serotonin['low'] = fuzz.gaussmf(x, 0, 0.3)
serotonin['medium'] = fuzz.gaussmf(x, 0.5, 0.1)
serotonin['high'] = fuzz.gaussmf(x, 1, 0.3)

noradrenaline['low'] = fuzz.gaussmf(y, 0, 0.3)
noradrenaline['medium'] = fuzz.gaussmf(y, 0.5, 0.1)
noradrenaline['high'] = fuzz.gaussmf(y, 1, 0.3)

dopamine['low'] = fuzz.gaussmf(z, 0, 0.3)
dopamine['medium'] = fuzz.gaussmf(z, 0.5, 0.1)
dopamine['high'] = fuzz.gaussmf(z, 1, 0.3)

def emotions_range(axis, emotions):
  axis[emotions[0]] = fuzz.gaussmf(plutchik_range, -1, 0.3)
  axis[emotions[1]] = fuzz.gaussmf(plutchik_range, -0.5, 0.1)
  axis[emotions[2]] = fuzz.gauss2mf(plutchik_range, -0.01, 0.3, -0.01, 0)
  axis[emotions[3]] = fuzz.gauss2mf(plutchik_range, 0.01, 0, 0.01, 0.3)
  axis[emotions[4]] = fuzz.gaussmf(plutchik_range, 0.5, 0.1)
  axis[emotions[5]] = fuzz.gaussmf(plutchik_range, 1, 0.3)
  axis[emotions[6]] = fuzz.trimf(plutchik_range, [-0.01, 0, 0.01])
  return axis

joy_axis = emotions_range(joy_axis, ['Grief', 'Sadness', 'Pensiveness', 'Serenity', 'Joy', 'Ecstasy', 'Neutral'])
disgust_axis = emotions_range(disgust_axis, ['Loathing', 'Disgust', 'Boredom', 'Neutral1', 'Neutral2', 'Neutral3', 'Neutral'])
fear_axis = emotions_range(fear_axis, ['Rage', 'Anger', 'Annoyance', 'Apprehension', 'Fear', 'Terror', 'Neutral'])
surprise_axis = emotions_range(surprise_axis, ['Vigilance', 'Anticipation', 'Interest', 'Distraction', 'Surprise', 'Amazement', 'Neutral'])

joy_axis_rule1 = ctrl.Rule(serotonin['low'] & noradrenaline['low'] & dopamine['low'], joy_axis['Pensiveness'])
joy_axis_rule2 = ctrl.Rule(serotonin['low'] & noradrenaline['medium'] & dopamine['low'], joy_axis['Sadness'])
joy_axis_rule3 = ctrl.Rule(serotonin['low'] & noradrenaline['high'] & dopamine['low'], joy_axis['Grief'])
joy_axis_rule4 = ctrl.Rule(serotonin['high'] & noradrenaline['low'] & dopamine['low'], joy_axis['Serenity'])
joy_axis_rule5 = ctrl.Rule(serotonin['low'] & noradrenaline['low'] & dopamine['high'], joy_axis['Serenity'])
joy_axis_rule6 = ctrl.Rule(serotonin['high'] & noradrenaline['low'] & dopamine['medium'], joy_axis['Joy'])
joy_axis_rule7 = ctrl.Rule(serotonin['medium'] & noradrenaline['low'] & dopamine['high'], joy_axis['Joy'])
joy_axis_rule8 = ctrl.Rule(serotonin['high'] & noradrenaline['low'] & dopamine['high'], joy_axis['Ecstasy'])
joy_axis_rule9 = ctrl.Rule(serotonin['medium'] & noradrenaline['medium'] & dopamine['medium'], joy_axis['Neutral'])

disgust_axis_rule1 = ctrl.Rule(serotonin['low'] & noradrenaline['low'] & dopamine['low'], disgust_axis['Boredom'])
disgust_axis_rule2 = ctrl.Rule(serotonin['medium'] & noradrenaline['low'] & dopamine['low'], disgust_axis['Disgust'])
disgust_axis_rule3 = ctrl.Rule(serotonin['high'] & noradrenaline['low'] & dopamine['low'], disgust_axis['Loathing'])
disgust_axis_rule4 = ctrl.Rule(serotonin['medium'] & noradrenaline['medium'] & dopamine['medium'], disgust_axis['Neutral'])
disgust_axis_rule5 = ctrl.Rule(serotonin['low'] & noradrenaline['low'] & dopamine['high'], disgust_axis['Neutral1'])
disgust_axis_rule6 = ctrl.Rule(serotonin['low'] & noradrenaline['high'] & dopamine['low'], disgust_axis['Neutral1'])
disgust_axis_rule7 = ctrl.Rule(serotonin['low'] & noradrenaline['medium'] & dopamine['high'], disgust_axis['Neutral2'])
disgust_axis_rule8 = ctrl.Rule(serotonin['low'] & noradrenaline['high'] & dopamine['medium'], disgust_axis['Neutral2'])
disgust_axis_rule9 = ctrl.Rule(serotonin['low'] & noradrenaline['high'] & dopamine['high'], disgust_axis['Neutral3'])

fear_axis_rule1 = ctrl.Rule(serotonin['low'] & noradrenaline['low'] & dopamine['low'], fear_axis['Apprehension'])
fear_axis_rule2 = ctrl.Rule(serotonin['low'] & noradrenaline['low'] & dopamine['medium'], fear_axis['Fear'])
fear_axis_rule3 = ctrl.Rule(serotonin['low'] & noradrenaline['low'] & dopamine['high'], fear_axis['Terror'])
fear_axis_rule4 = ctrl.Rule(noradrenaline['high'] & dopamine['low'], fear_axis['Annoyance'])
fear_axis_rule5 = ctrl.Rule(noradrenaline['high'] & dopamine['medium'], fear_axis['Anger'])
fear_axis_rule6 = ctrl.Rule(noradrenaline['high'] & dopamine['high'], fear_axis['Rage'])
fear_axis_rule7 = ctrl.Rule(serotonin['medium'] & noradrenaline['medium'] & dopamine['medium'], fear_axis['Neutral'])

surprise_axis_rule1 = ctrl.Rule(serotonin['low'] & noradrenaline['high'] & dopamine['high'], surprise_axis['Interest'])
surprise_axis_rule2 = ctrl.Rule(serotonin['high'] & noradrenaline['low'] & dopamine['high'], surprise_axis['Interest'])
surprise_axis_rule3 = ctrl.Rule(serotonin['high'] & noradrenaline['medium'] & dopamine['high'], surprise_axis['Anticipation'])
surprise_axis_rule4 = ctrl.Rule(serotonin['medium'] & noradrenaline['high'] & dopamine['high'], surprise_axis['Anticipation'])
surprise_axis_rule5 = ctrl.Rule(serotonin['high'] & noradrenaline['high'] & dopamine['high'], surprise_axis['Vigilance'])
surprise_axis_rule6 = ctrl.Rule(serotonin['high'] & noradrenaline['low'] & dopamine['low'], surprise_axis['Distraction'])
surprise_axis_rule7 = ctrl.Rule(serotonin['low'] & noradrenaline['high'] & dopamine['low'], surprise_axis['Distraction'])
surprise_axis_rule8 = ctrl.Rule(serotonin['high'] & noradrenaline['medium'] & dopamine['low'], surprise_axis['Surprise'])
surprise_axis_rule9 = ctrl.Rule(serotonin['medium'] & noradrenaline['high'] & dopamine['low'], surprise_axis['Surprise'])
surprise_axis_rule10 = ctrl.Rule(serotonin['high'] & noradrenaline['high'] & dopamine['low'], surprise_axis['Amazement'])
surprise_axis_rule11 = ctrl.Rule(serotonin['medium'] & noradrenaline['medium'] & dopamine['medium'], surprise_axis['Neutral'])

joy_ctrl = ctrl.ControlSystem([joy_axis_rule1, joy_axis_rule2, joy_axis_rule3, joy_axis_rule4, joy_axis_rule5, joy_axis_rule6, joy_axis_rule7, joy_axis_rule8, joy_axis_rule9])
disgust_ctrl = ctrl.ControlSystem([disgust_axis_rule1, disgust_axis_rule2, disgust_axis_rule3, disgust_axis_rule4, disgust_axis_rule5, disgust_axis_rule6, disgust_axis_rule7, disgust_axis_rule8, disgust_axis_rule9])
fear_ctrl = ctrl.ControlSystem([fear_axis_rule1, fear_axis_rule2, fear_axis_rule3, fear_axis_rule4, fear_axis_rule5, fear_axis_rule6, fear_axis_rule7])
surprise_ctrl = ctrl.ControlSystem([surprise_axis_rule1, surprise_axis_rule2, surprise_axis_rule3, surprise_axis_rule4, surprise_axis_rule5, surprise_axis_rule6, surprise_axis_rule7, surprise_axis_rule8, surprise_axis_rule9, surprise_axis_rule10, surprise_axis_rule11])

joy_level = ctrl.ControlSystemSimulation(joy_ctrl)
disgust_level = ctrl.ControlSystemSimulation(disgust_ctrl)
fear_level = ctrl.ControlSystemSimulation(fear_ctrl)
surprise_level = ctrl.ControlSystemSimulation(surprise_ctrl)

def calculate_output(ser_val, nor_val, dop_val, axis, axis_name, axis_level):
  axis_level.input['serotonin'] = ser_val
  axis_level.input['noradrenaline'] = nor_val
  axis_level.input['dopamine'] = dop_val
  try:
    axis_level.compute()
  except ValueError as e:
    print("Not possible")
    return
  emotions = list(axis.terms.keys())
  result = axis_level.output[axis_name]
  memberships = {}
  memberships[emotions[0]] = fuzz.interp_membership(plutchik_range, axis[emotions[0]].mf, axis_level.output[axis_name])
  memberships[emotions[1]] = fuzz.interp_membership(plutchik_range, axis[emotions[1]].mf, axis_level.output[axis_name])
  memberships[emotions[2]] = fuzz.interp_membership(plutchik_range, axis[emotions[2]].mf, axis_level.output[axis_name])
  memberships[emotions[3]] = fuzz.interp_membership(plutchik_range, axis[emotions[3]].mf, axis_level.output[axis_name])
  memberships[emotions[4]] = fuzz.interp_membership(plutchik_range, axis[emotions[4]].mf, axis_level.output[axis_name])
  memberships[emotions[5]] = fuzz.interp_membership(plutchik_range, axis[emotions[5]].mf, axis_level.output[axis_name])
  memberships[emotions[6]] = fuzz.interp_membership(plutchik_range, axis[emotions[6]].mf, axis_level.output[axis_name])
  return memberships

def untie_emotions1(emotions):
    max_score = max(emotions.values())
    max_emotions = [key for key, value in emotions.items() if value == max_score]

    # print(f"{random.choice(max_emotions)}")
    return random.choice(max_emotions)

def insert_neuro_values3(ser_val, nor_val, dop_val):
  joy_prob = calculate_output(ser_val, nor_val, dop_val, joy_axis, "joy_axis", joy_level)
  disgust_prob = calculate_output(ser_val, nor_val, dop_val, disgust_axis, "disgust_axis", disgust_level)
  fear_prob = calculate_output(ser_val, nor_val, dop_val, fear_axis, "fear_axis", fear_level)
  surprise_prob = calculate_output(ser_val, nor_val, dop_val, surprise_axis, "surprise_axis", surprise_level)
  emotions_prob = {}
  joy_prob = {key: value for key, value in joy_prob.items()}
  disgust_prob = {key: value for key, value in disgust_prob.items()}
  fear_prob = {key: value for key, value in fear_prob.items()}
  surprise_prob = {key: value for key, value in surprise_prob.items()}
  if len(joy_prob) > 0: 
    emotions_prob[max(joy_prob, key=joy_prob.get)] = joy_prob[max(joy_prob, key=joy_prob.get)]
  if len(disgust_prob) > 0:
    emotions_prob[max(disgust_prob, key=disgust_prob.get)] = disgust_prob[max(disgust_prob, key=disgust_prob.get)]
  if len(fear_prob) > 0: 
    emotions_prob[max(fear_prob, key=fear_prob.get)] = fear_prob[max(fear_prob, key=fear_prob.get)]
  if len(surprise_prob) > 0: 
    emotions_prob[max(surprise_prob, key=surprise_prob.get)] = surprise_prob[max(surprise_prob, key=surprise_prob.get)]
  if 'Neutral' in emotions_prob:
    if len(emotions_prob) != 1:
      del emotions_prob['Neutral']
  if 'Neutral1' in emotions_prob:
    del emotions_prob['Neutral1']
  if 'Neutral2' in emotions_prob:
    del emotions_prob['Neutral2']
  if 'Neutral3' in emotions_prob:
    del emotions_prob['Neutral3']
  return random.choice(list(emotions_prob.keys()))
  # if sum(1 for value in emotions_prob.values() if value == max(emotions_prob.values())) > 1:
  #   # untie_emotions1(emotions_prob)
  #   return untie_emotions1(emotions_prob)
  # else:
  #     # print(max(emotions_prob, key=emotions_prob.get))
  #     return max(emotions_prob, key=emotions_prob.get)

print(insert_neuro_values3(ser_val, nor_val, dop_val))

# f = open("Assets/Scripts/PythonScripts/results.txt", "w")
# for i in range(0, 11):
#     for j in range(0, 11):
#         for k in range(0, 11):
#             f.write(f"{i/10},{j/10},{k/10};{insert_neuro_values3(i/10, j/10, k/10)}\n")
# f.close()