# FUTURE FALLS

## Game controls:

![joystick_controllers](https://user-images.githubusercontent.com/15311320/124325678-75375700-db5b-11eb-8e5a-48873abe3619.png)
![keyboard_controllers](https://user-images.githubusercontent.com/15311320/124325684-78324780-db5b-11eb-8526-850638451fc8.png)

## Game Builds:
## A build of the game is available as FutureFallsBuilds.zip.
## After unzipping it, you will choose the folder related to your OS, and then click in the executable.
