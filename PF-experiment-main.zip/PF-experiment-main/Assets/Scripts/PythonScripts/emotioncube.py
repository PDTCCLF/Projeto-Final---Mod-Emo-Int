import numpy as np
import matplotlib.pyplot as plt
import skfuzzy as fuzz
from skfuzzy import control as ctrl
import random
import sys

values = sys.argv[1].split(',')
ser_val = float(values[0])
nor_val = float(values[1])
dop_val = float(values[2])

def point_distance(ser, nor, dop, x, y, z):
  return np.sqrt((ser-x)**2 + (nor-y)**2 + (dop-z)**2)

def distance_score(ser, nor, dop, x, y, z):
    return (1 - point_distance(ser, nor, dop, x, y, z) / np.sqrt(3)) * 100

def untie_emotions(score, emotions):
    max_score = max(score)
    max_emotions = []
    for i in range(len(score)):
        if score[i] == max_score:
            max_emotions.append(emotions[i])

    # return random.choice(max_emotions)
    print(f"{random.choice(max_emotions)}")

def get_best_score(ser, nor, dop):
    emotions = ['Interest/Excitement', 'Anger/Rage', 'Fear/Terror', 'Surprise', 'Enjoyment/Joy', 'Distress/Anguish', 'Shame/Humiliation', 'Contempt/Disgust']
    score = []
    score.append(distance_score(ser, nor, dop, 1, 1, 1))
    score.append(distance_score(ser, nor, dop, 0, 1, 1))
    score.append(distance_score(ser, nor, dop, 0, 0, 1))
    score.append(distance_score(ser, nor, dop, 1, 1, 0))
    score.append(distance_score(ser, nor, dop, 1, 0, 1))
    score.append(distance_score(ser, nor, dop, 0, 1, 0))
    score.append(distance_score(ser, nor, dop, 0, 0, 0))
    score.append(distance_score(ser, nor, dop, 1, 0, 0))

    max_score = max(score)
    total_score = sum(score)

    if score.count(max_score) > 1:
        normalization_factor = 100 / total_score
        for i in range(len(score)):
            score[i] *= normalization_factor
    else:
        normalization_factor = (100 - max_score) / (total_score - max_score)
        for i in range(len(score)):
            if score[i] != max_score:
                score[i] *= normalization_factor

    if score.count(max(score)) > 1:
        # return untie_emotions(score, emotions)
        untie_emotions(score, emotions)
    else:
        # return emotions[score.index(max(score))]
        print(f"{emotions[score.index(max(score))]}")

get_best_score(ser_val, nor_val, dop_val)

# f = open("Assets/Scripts/PythonScripts/results.txt", "w")
# for i in range(0, 11):
#     for j in range(0, 11):
#         for k in range(0, 11):
#             f.write(f"{i/10},{j/10},{k/10};{get_best_score(i/10, j/10, k/10)}\n")
# f.close()