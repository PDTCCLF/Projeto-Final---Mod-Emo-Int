import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl
import random
import sys

values = sys.argv[1].split(',')
ser_val = float(values[0])
nor_val = float(values[1])
dop_val = float(values[2])

def point_distance(ser, nor, dop, x, y, z):
  return np.sqrt((ser-x)**2 + (nor-y)**2 + (dop-z)**2)

def distance_score(ser, nor, dop, x, y, z):
    return (1 - point_distance(ser, nor, dop, x, y, z) / np.sqrt(3)) * 100

def untie_emotions(score, emotions):
    max_score = max(score)
    max_emotions = []
    for i in range(len(score)):
        if score[i] == max_score:
            max_emotions.append(emotions[i])
    random_emotion = random.choice(max_emotions)
    if '/' in random_emotion:
        result_emotions = random_emotion.split('/')
        # print(f"{random.choice(result_emotions)}")
        return random.choice(result_emotions)
    else:    
        # print(f"{random_emotion}")
        return random_emotion

def get_best_score1(ser, nor, dop):
    emotions = ['Vigilance', 'Rage/Interest', 'Distraction/Annoyance/Grief', 'Amazement/Interest', 'Ecstasy/Interest', 'Serenity/Annoyance/Terror',
  'Apprehension/Boredom/Pensiveness', 'Loathing/Serenity/Distraction', 'Anticipation', 'Anger', 'Surprise', 'Anticipation', 'Joy',
  'Fear', 'Disgust', 'Joy', 'Anticipation', 'Anger', 'Sadness', 'Surprise', 'Neutral']
    score = []
    score.append(distance_score(ser, nor, dop, 1, 1, 1))
    score.append(distance_score(ser, nor, dop, 0, 1, 1))
    score.append(distance_score(ser, nor, dop, 0, 1, 0))
    score.append(distance_score(ser, nor, dop, 1, 1, 0))
    score.append(distance_score(ser, nor, dop, 1, 0, 1))
    score.append(distance_score(ser, nor, dop, 0, 0, 1))
    score.append(distance_score(ser, nor, dop, 0, 0, 0))
    score.append(distance_score(ser, nor, dop, 1, 0, 0))
    score.append(distance_score(ser, nor, dop, 0.5, 1, 1))
    score.append(distance_score(ser, nor, dop, 0, 0.5, 1))
    score.append(distance_score(ser, nor, dop, 1, 0.5, 0))
    score.append(distance_score(ser, nor, dop, 1, 0.5, 1))
    score.append(distance_score(ser, nor, dop, 0.5, 0, 1))
    score.append(distance_score(ser, nor, dop, 0, 0, 0.5))
    score.append(distance_score(ser, nor, dop, 0.5, 0, 0))
    score.append(distance_score(ser, nor, dop, 1, 0, 0.5))
    score.append(distance_score(ser, nor, dop, 1, 1, 0.5))
    score.append(distance_score(ser, nor, dop, 0, 1, 0.5))
    score.append(distance_score(ser, nor, dop, 0, 0.5, 0))
    score.append(distance_score(ser, nor, dop, 0.5, 1, 0))
    score.append(distance_score(ser, nor, dop, 0.5, 0.5, 0.5))


    max_score = max(score)
    total_score = sum(score)

    if score.count(max_score) > 1:
        normalization_factor = 100 / total_score
        for i in range(len(score)):
            score[i] *= normalization_factor
    else:
        normalization_factor = (100 - max_score) / (total_score - max_score)
        for i in range(len(score)):
            if score[i] != max_score:
                score[i] *= normalization_factor

    if score.count(max(score)) > 1:
      return untie_emotions(score, emotions)
    else:
        if '/' in emotions[score.index(max(score))]:
          result_emotions = emotions[score.index(max(score))].split('/')
          # print(f"{random.choice(result_emotions)}")  
          return random.choice(result_emotions)
        else:    
          # print(f"{emotions[score.index(max(score))]}")
          return emotions[score.index(max(score))]

# get_best_score1(ser_val, nor_val, dop_val)

f = open("Assets/Scripts/PythonScripts/results.txt", "w")
for i in range(0, 11):
    for j in range(0, 11):
        for k in range(0, 11):
            f.write(f"{i/10},{j/10},{k/10};{get_best_score1(i/10, j/10, k/10)}\n")
f.close()