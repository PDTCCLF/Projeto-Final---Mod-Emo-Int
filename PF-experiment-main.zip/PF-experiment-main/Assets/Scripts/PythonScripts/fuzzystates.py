import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl
import random
import sys
import warnings

# Ignore RuntimeWarning
warnings.filterwarnings("ignore", category=RuntimeWarning)

values = sys.argv[1].split(',')
mode = values[0]
if (mode == "first"):
    ser_val = float(values[1])
    nor_val = float(values[2])
    dop_val = float(values[3])
else:
    fuzzy_res1 = values[1]
    fuzzy_res2 = values[2]
    fuzzy_res3 = values[3]
    fuzzy_res4 = values[4]

x = np.arange(0, 1, 0.001)
y = np.arange(0, 1, 0.001)
z = np.arange(0, 1, 0.001)
plutchik_range = np.arange(-1, 1, 0.001)

serotonin = ctrl.Antecedent(x, 'serotonin')
noradrenaline = ctrl.Antecedent(y, 'noradrenaline')
dopamine = ctrl.Antecedent(z, 'dopamine')
joy_axis = ctrl.Consequent(plutchik_range, 'joy_axis')
disgust_axis = ctrl.Consequent(plutchik_range, 'disgust_axis')
fear_axis = ctrl.Consequent(plutchik_range, 'fear_axis')
surprise_axis = ctrl.Consequent(plutchik_range, 'surprise_axis')

serotonin['low'] = fuzz.gaussmf(x, 0, 0.3)
serotonin['medium'] = fuzz.gaussmf(x, 0.5, 0.1)
serotonin['high'] = fuzz.gaussmf(x, 1, 0.3)

noradrenaline['low'] = fuzz.gaussmf(y, 0, 0.3)
noradrenaline['medium'] = fuzz.gaussmf(y, 0.5, 0.1)
noradrenaline['high'] = fuzz.gaussmf(y, 1, 0.3)

dopamine['low'] = fuzz.gaussmf(z, 0, 0.3)
dopamine['medium'] = fuzz.gaussmf(z, 0.5, 0.1)
dopamine['high'] = fuzz.gaussmf(z, 1, 0.3)

def emotions_range(axis, emotions):
  axis[emotions[0]] = fuzz.gaussmf(plutchik_range, -1, 0.3)
  axis[emotions[1]] = fuzz.gaussmf(plutchik_range, -0.5, 0.1)
  axis[emotions[2]] = fuzz.gauss2mf(plutchik_range, -0.01, 0.3, -0.01, 0)
  axis[emotions[3]] = fuzz.gauss2mf(plutchik_range, 0.01, 0, 0.01, 0.3)
  axis[emotions[4]] = fuzz.gaussmf(plutchik_range, 0.5, 0.1)
  axis[emotions[5]] = fuzz.gaussmf(plutchik_range, 1, 0.3)
  axis[emotions[6]] = fuzz.trimf(plutchik_range, [-0.01, 0, 0.01])
  return axis

joy_axis = emotions_range(joy_axis, ['Grief', 'Sadness', 'Pensiveness', 'Serenity', 'Joy', 'Ecstasy', 'Neutral'])
disgust_axis = emotions_range(disgust_axis, ['Loathing', 'Disgust', 'Boredom', 'Neutral1', 'Neutral2', 'Neutral3', 'Neutral'])
fear_axis = emotions_range(fear_axis, ['Rage', 'Anger', 'Annoyance', 'Apprehension', 'Fear', 'Terror', 'Neutral'])
surprise_axis = emotions_range(surprise_axis, ['Vigilance', 'Anticipation', 'Interest', 'Distraction', 'Surprise', 'Amazement', 'Neutral'])

joy_axis_rule1 = ctrl.Rule(serotonin['low'] & noradrenaline['low'] & dopamine['low'], joy_axis['Pensiveness'])
joy_axis_rule2 = ctrl.Rule(serotonin['low'] & noradrenaline['medium'] & dopamine['low'], joy_axis['Sadness'])
joy_axis_rule3 = ctrl.Rule(serotonin['low'] & noradrenaline['high'] & dopamine['low'], joy_axis['Grief'])
joy_axis_rule4 = ctrl.Rule(serotonin['high'] & noradrenaline['low'] & dopamine['low'], joy_axis['Serenity'])
joy_axis_rule5 = ctrl.Rule(serotonin['low'] & noradrenaline['low'] & dopamine['high'], joy_axis['Serenity'])
joy_axis_rule6 = ctrl.Rule(serotonin['high'] & noradrenaline['low'] & dopamine['medium'], joy_axis['Joy'])
joy_axis_rule7 = ctrl.Rule(serotonin['medium'] & noradrenaline['low'] & dopamine['high'], joy_axis['Joy'])
joy_axis_rule8 = ctrl.Rule(serotonin['high'] & noradrenaline['low'] & dopamine['high'], joy_axis['Ecstasy'])
joy_axis_rule9 = ctrl.Rule(serotonin['medium'] & noradrenaline['medium'] & dopamine['medium'], joy_axis['Neutral'])

disgust_axis_rule1 = ctrl.Rule(serotonin['low'] & noradrenaline['low'] & dopamine['low'], disgust_axis['Boredom'])
disgust_axis_rule2 = ctrl.Rule(serotonin['medium'] & noradrenaline['low'] & dopamine['low'], disgust_axis['Disgust'])
disgust_axis_rule3 = ctrl.Rule(serotonin['high'] & noradrenaline['low'] & dopamine['low'], disgust_axis['Loathing'])
disgust_axis_rule4 = ctrl.Rule(serotonin['medium'] & noradrenaline['medium'] & dopamine['medium'], disgust_axis['Neutral'])
disgust_axis_rule5 = ctrl.Rule(serotonin['low'] & noradrenaline['low'] & dopamine['high'], disgust_axis['Neutral1'])
disgust_axis_rule6 = ctrl.Rule(serotonin['low'] & noradrenaline['high'] & dopamine['low'], disgust_axis['Neutral1'])
disgust_axis_rule7 = ctrl.Rule(serotonin['low'] & noradrenaline['medium'] & dopamine['high'], disgust_axis['Neutral2'])
disgust_axis_rule8 = ctrl.Rule(serotonin['low'] & noradrenaline['high'] & dopamine['medium'], disgust_axis['Neutral2'])
disgust_axis_rule9 = ctrl.Rule(serotonin['low'] & noradrenaline['high'] & dopamine['high'], disgust_axis['Neutral3'])

fear_axis_rule1 = ctrl.Rule(serotonin['low'] & noradrenaline['low'] & dopamine['low'], fear_axis['Apprehension'])
fear_axis_rule2 = ctrl.Rule(serotonin['low'] & noradrenaline['low'] & dopamine['medium'], fear_axis['Fear'])
fear_axis_rule3 = ctrl.Rule(serotonin['low'] & noradrenaline['low'] & dopamine['high'], fear_axis['Terror'])
fear_axis_rule4 = ctrl.Rule(noradrenaline['high'] & dopamine['low'], fear_axis['Annoyance'])
fear_axis_rule5 = ctrl.Rule(noradrenaline['high'] & dopamine['medium'], fear_axis['Anger'])
fear_axis_rule6 = ctrl.Rule(noradrenaline['high'] & dopamine['high'], fear_axis['Rage'])
fear_axis_rule7 = ctrl.Rule(serotonin['medium'] & noradrenaline['medium'] & dopamine['medium'], fear_axis['Neutral'])

surprise_axis_rule1 = ctrl.Rule(serotonin['low'] & noradrenaline['high'] & dopamine['high'], surprise_axis['Interest'])
surprise_axis_rule2 = ctrl.Rule(serotonin['high'] & noradrenaline['low'] & dopamine['high'], surprise_axis['Interest'])
surprise_axis_rule3 = ctrl.Rule(serotonin['high'] & noradrenaline['medium'] & dopamine['high'], surprise_axis['Anticipation'])
surprise_axis_rule4 = ctrl.Rule(serotonin['medium'] & noradrenaline['high'] & dopamine['high'], surprise_axis['Anticipation'])
surprise_axis_rule5 = ctrl.Rule(serotonin['high'] & noradrenaline['high'] & dopamine['high'], surprise_axis['Vigilance'])
surprise_axis_rule6 = ctrl.Rule(serotonin['high'] & noradrenaline['low'] & dopamine['low'], surprise_axis['Distraction'])
surprise_axis_rule7 = ctrl.Rule(serotonin['low'] & noradrenaline['high'] & dopamine['low'], surprise_axis['Distraction'])
surprise_axis_rule8 = ctrl.Rule(serotonin['high'] & noradrenaline['medium'] & dopamine['low'], surprise_axis['Surprise'])
surprise_axis_rule9 = ctrl.Rule(serotonin['medium'] & noradrenaline['high'] & dopamine['low'], surprise_axis['Surprise'])
surprise_axis_rule10 = ctrl.Rule(serotonin['high'] & noradrenaline['high'] & dopamine['low'], surprise_axis['Amazement'])
surprise_axis_rule11 = ctrl.Rule(serotonin['medium'] & noradrenaline['medium'] & dopamine['medium'], surprise_axis['Neutral'])

joy_ctrl = ctrl.ControlSystem([joy_axis_rule1, joy_axis_rule2, joy_axis_rule3, joy_axis_rule4, joy_axis_rule5, joy_axis_rule6, joy_axis_rule7, joy_axis_rule8, joy_axis_rule9])
disgust_ctrl = ctrl.ControlSystem([disgust_axis_rule1, disgust_axis_rule2, disgust_axis_rule3, disgust_axis_rule4, disgust_axis_rule5, disgust_axis_rule6, disgust_axis_rule7, disgust_axis_rule8, disgust_axis_rule9])
fear_ctrl = ctrl.ControlSystem([fear_axis_rule1, fear_axis_rule2, fear_axis_rule3, fear_axis_rule4, fear_axis_rule5, fear_axis_rule6, fear_axis_rule7])
surprise_ctrl = ctrl.ControlSystem([surprise_axis_rule1, surprise_axis_rule2, surprise_axis_rule3, surprise_axis_rule4, surprise_axis_rule5, surprise_axis_rule6, surprise_axis_rule7, surprise_axis_rule8, surprise_axis_rule9, surprise_axis_rule10, surprise_axis_rule11])

joy_level = ctrl.ControlSystemSimulation(joy_ctrl)
disgust_level = ctrl.ControlSystemSimulation(disgust_ctrl)
fear_level = ctrl.ControlSystemSimulation(fear_ctrl)
surprise_level = ctrl.ControlSystemSimulation(surprise_ctrl)

def untie_emotions2(emotions):
    max_score = max(emotions.values())
    max_emotions = [key for key, value in emotions.items() if value == max_score]

    return random.choice(max_emotions)

def calculate_output2(ser_val, nor_val, dop_val, axis, axis_name, axis_level):
  axis_level.input['serotonin'] = ser_val
  axis_level.input['noradrenaline'] = nor_val
  axis_level.input['dopamine'] = dop_val
  try:
    axis_level.compute()
  except ValueError as e:
    print("Not possible")
    return
  emotions = list(axis.terms.keys())
  result = axis_level.output[axis_name]
  memberships = {}
  memberships[emotions[0]] = fuzz.interp_membership(plutchik_range, axis[emotions[0]].mf, axis_level.output[axis_name])
  memberships[emotions[1]] = fuzz.interp_membership(plutchik_range, axis[emotions[1]].mf, axis_level.output[axis_name])
  memberships[emotions[2]] = fuzz.interp_membership(plutchik_range, axis[emotions[2]].mf, axis_level.output[axis_name])
  memberships[emotions[3]] = fuzz.interp_membership(plutchik_range, axis[emotions[3]].mf, axis_level.output[axis_name])
  memberships[emotions[4]] = fuzz.interp_membership(plutchik_range, axis[emotions[4]].mf, axis_level.output[axis_name])
  memberships[emotions[5]] = fuzz.interp_membership(plutchik_range, axis[emotions[5]].mf, axis_level.output[axis_name])
  memberships[emotions[6]] = fuzz.interp_membership(plutchik_range, axis[emotions[6]].mf, axis_level.output[axis_name])
  return memberships

def insert_neuro_values4(ser_val, nor_val, dop_val):
  joy_prob = calculate_output2(ser_val, nor_val, dop_val, joy_axis, "joy_axis", joy_level)
  disgust_prob = calculate_output2(ser_val, nor_val, dop_val, disgust_axis, "disgust_axis", disgust_level)
  fear_prob = calculate_output2(ser_val, nor_val, dop_val, fear_axis, "fear_axis", fear_level)
  surprise_prob = calculate_output2(ser_val, nor_val, dop_val, surprise_axis, "surprise_axis", surprise_level)
  emotions_prob = {}
  result_emotions = []
  joy_prob = {key: value for key, value in joy_prob.items()}
  disgust_prob = {key: value for key, value in disgust_prob.items()}
  fear_prob = {key: value for key, value in fear_prob.items()}
  surprise_prob = {key: value for key, value in surprise_prob.items()}
  if len(joy_prob) > 0: 
    result_emotions.append(max(joy_prob, key=joy_prob.get))
    emotions_prob[max(joy_prob, key=joy_prob.get)] = joy_prob[max(joy_prob, key=joy_prob.get)]
  if len(disgust_prob) > 0:
    result_emotions.append(max(disgust_prob, key=disgust_prob.get))
    emotions_prob[max(disgust_prob, key=disgust_prob.get)] = disgust_prob[max(disgust_prob, key=disgust_prob.get)]
  if len(fear_prob) > 0: 
    result_emotions.append(max(fear_prob, key=fear_prob.get))
    emotions_prob[max(fear_prob, key=fear_prob.get)] = fear_prob[max(fear_prob, key=fear_prob.get)]
  if len(surprise_prob) > 0: 
    result_emotions.append(max(surprise_prob, key=surprise_prob.get))
    emotions_prob[max(surprise_prob, key=surprise_prob.get)] = surprise_prob[max(surprise_prob, key=surprise_prob.get)]
  if 'Neutral' in emotions_prob:
    if len(emotions_prob) != 1:
      del emotions_prob['Neutral']
  if 'Neutral1' in emotions_prob:
    del emotions_prob['Neutral1']
  if 'Neutral2' in emotions_prob:
    del emotions_prob['Neutral2']
  if 'Neutral3' in emotions_prob:
    del emotions_prob['Neutral3']
  if sum(1 for value in emotions_prob.values() if value == max(emotions_prob.values())) > 1:
    # untie_emotions1(emotions_prob)
    result_emotions.append(untie_emotions2(emotions_prob))
  else:
      # print(max(emotions_prob, key=emotions_prob.get))
      result_emotions.append(max(emotions_prob, key=emotions_prob.get))
  return result_emotions


# Define fuzzy states
class FuzzyState:
    def __init__(self, name, membership):
        self.name = name
        self.membership = membership

def transition(current_state, states, axis):
    # Define transition rules based on current state and membership levels
    transition_rules = {
        'Pensiveness': ('Sadness', 'Neutral'),
        'Sadness': ('Grief', 'Pensiveness'),
        'Grief': ('Sadness',),
        'Serenity': ('Neutral', 'Joy'),
        'Joy': ('Serenity', 'Ecstasy'),
        'Ecstasy': ('Joy',),
        'Boredom': ('Disgust', 'Neutral'),
        'Disgust': ('Loathing', 'Boredom'),
        'Loathing': ('Disgust',),
        'Neutral1': ('Neutral', 'Neutral2'),
        'Neutral2': ('Neutral1', 'Neutral3'),
        'Neutral3': ('Neutral2',),
        'Annoyance': ('Anger', 'Neutral'),
        'Anger': ('Rage', 'Annoyance'),
        'Rage': ('Anger',),
        'Apprehension': ('Neutral', 'Fear'),
        'Fear': ('Apprehension', 'Terror'),
        'Terror': ('Fear',),
        'Interest': ('Anticipation', 'Neutral'),
        'Anticipation': ('Vigilance', 'Interest'),
        'Vigilance': ('Anticipation',),
        'Distraction': ('Neutral', 'Surprise'),
        'Surprise': ('Distraction', 'Amazement'),
        'Amazement': ('Surprise',),
    }

    if axis == 'joy_axis':
        transition_rules['Neutral'] = ('Pensiveness', 'Serenity')
    elif axis == 'disgust_axis':
        transition_rules['Neutral'] = ('Boredom', 'Neutral1')
    elif axis == 'fear_axis':
        transition_rules['Neutral'] = ('Annoyance', 'Apprehension')
    elif axis == 'surprise_axis':
        transition_rules['Neutral'] = ('Interest', 'Distraction')

    # Get the membership level of the current state
    current_membership = next((state.membership for state in states if state.name == current_state), None)
    if current_membership is None:
        next_state = FuzzyState(current_state, current_membership)
        return next_state  # If current state not found, remain in current state

    # Determine the next state based on the highest membership level and transition rules
    next_states = transition_rules[current_state]

    # Determine the next state based on the highest membership level and transition rules
    next_states = transition_rules[current_state]
    if axis == 'joy_axis':
      next_state_name = max(next_states, key=lambda state: fuzz.interp_membership(plutchik_range, joy_axis[state].mf, joy_level.output['joy_axis']))
      if sum(1 for state in states if state.name in next_states and state.membership == fuzz.interp_membership(plutchik_range, joy_axis[next_state_name].mf, joy_level.output['joy_axis'])) > 1:
            next_state_name = random.choice(next_states)
            # print("VNFDBLMDGLSMDKD1")
      next_state = FuzzyState(next_state_name, fuzz.interp_membership(plutchik_range, joy_axis[next_state_name].mf, joy_level.output['joy_axis']))
    elif axis == 'disgust_axis':
        next_state_name = max(next_states, key=lambda state: fuzz.interp_membership(plutchik_range, disgust_axis[state].mf, disgust_level.output['disgust_axis']))
        if sum(1 for state in states if state.name in next_states and state.membership == fuzz.interp_membership(plutchik_range, disgust_axis[next_state_name].mf, disgust_level.output['disgust_axis'])) > 1:
                next_state_name = random.choice(next_states)
                # print("VNFDBLMDGLSMDKD2")
        next_state = FuzzyState(next_state_name, fuzz.interp_membership(plutchik_range, disgust_axis[next_state_name].mf, disgust_level.output['disgust_axis']))
    elif axis == 'fear_axis':
        next_state_name = max(next_states, key=lambda state: fuzz.interp_membership(plutchik_range, fear_axis[state].mf, fear_level.output['fear_axis']))
        if sum(1 for state in states if state.name in next_states and state.membership == fuzz.interp_membership(plutchik_range, fear_axis[next_state_name].mf, fear_level.output['fear_axis'])) > 1:
                next_state_name = random.choice(next_states)
                # print("VNFDBLMDGLSMDKD3")
        next_state = FuzzyState(next_state_name, fuzz.interp_membership(plutchik_range, fear_axis[next_state_name].mf, fear_level.output['fear_axis']))
    elif axis == 'surprise_axis':
        next_state_name = max(next_states, key=lambda state: fuzz.interp_membership(plutchik_range, surprise_axis[state].mf, surprise_level.output['surprise_axis']))
        if sum(1 for state in states if state.name in next_states and state.membership == fuzz.interp_membership(plutchik_range, surprise_axis[next_state_name].mf, surprise_level.output['surprise_axis'])) > 1:
                next_state_name = random.choice(next_states)
                # print("VNFDBLMDGLSMDKD4")
        next_state = FuzzyState(next_state_name, fuzz.interp_membership(plutchik_range, surprise_axis[next_state_name].mf, surprise_level.output['surprise_axis']))
    # Check if next state has 0 membership level and if so, remain in current state
    if next_state.membership == 0:
        next_state = FuzzyState(current_state, current_membership)
    return next_state

# Simulate the system
def simulate_system(joy_current_state, disgust_current_state, fear_current_state, surprise_current_state):
    joy_level.compute()
    disgust_level.compute()
    fear_level.compute()
    surprise_level.compute()

    joy_next_state = transition(joy_current_state, joy_states, 'joy_axis')
    disgust_next_state = transition(disgust_current_state, disgust_states, 'disgust_axis')
    fear_next_state = transition(fear_current_state, fear_states, 'fear_axis')
    surprise_next_state = transition(surprise_current_state, surprise_states, 'surprise_axis')


    # Join the next states from all axes into a single dictionary
    next_states = {
        joy_next_state.name: joy_next_state.membership,
        disgust_next_state.name: disgust_next_state.membership,
        fear_next_state.name: fear_next_state.membership,
        surprise_next_state.name: surprise_next_state.membership
    }

    states = [joy_next_state.name, disgust_next_state.name, fear_next_state.name, surprise_next_state.name]

    if "Neutral1" in next_states:
      del next_states["Neutral1"]
    if "Neutral2" in next_states:
        del next_states["Neutral2"]
    if "Neutral3" in next_states:
        del next_states["Neutral3"]
    if "Neutral" in next_states:
      if (sum(1 for key in next_states.keys() if key == 'Neutral') == len(next_states)):
          return "Neutral"
      else:
        del next_states["Neutral"]
    # Determine the final state based on the highest membership level
    if sum(1 for value in next_states.values() if value == max(next_states.values())) > 1:
        states.append(untie_emotions2(next_states))
    else:
        states.append(max(next_states, key=next_states.get))
    return states

if (mode == "first"):
    fuzzy_res = insert_neuro_values4(ser_val, nor_val, dop_val)
    print(fuzzy_res[0] + "," + fuzzy_res[1] + "," + fuzzy_res[2] + "," + fuzzy_res[3] + "," + fuzzy_res[4])
else:
    fuzzy_res = insert_neuro_values4(0, 0, 0)
    # Define fuzzy states based on joy_axis output (emotions)
    joy_emotions = ['Grief', 'Sadness', 'Pensiveness', 'Neutral', 'Serenity', 'Joy', 'Ecstasy']
    disgust_emotions = ['Loathing', 'Disgust', 'Boredom', 'Neutral', 'Neutral1', 'Neutral2', 'Neutral3']
    fear_emotions = ['Rage', 'Anger', 'Annoyance', 'Neutral', 'Apprehension', 'Fear', 'Terror']
    surprise_emotions = ['Vigilance', 'Anticipation', 'Interest', 'Neutral', 'Distraction', 'Surprise', 'Amazement']
    joy_states = [FuzzyState(emotion, fuzz.interp_membership(plutchik_range, joy_axis[emotion].mf, joy_level.output['joy_axis'])) for emotion in joy_emotions]
    disgust_states = [FuzzyState(emotion, fuzz.interp_membership(plutchik_range, disgust_axis[emotion].mf, disgust_level.output['disgust_axis'])) for emotion in disgust_emotions]
    fear_states = [FuzzyState(emotion, fuzz.interp_membership(plutchik_range, fear_axis[emotion].mf, fear_level.output['fear_axis'])) for emotion in fear_emotions]
    surprise_states = [FuzzyState(emotion, fuzz.interp_membership(plutchik_range, surprise_axis[emotion].mf, surprise_level.output['surprise_axis'])) for emotion in surprise_emotions]
    result = simulate_system(fuzzy_res1, fuzzy_res2, fuzzy_res3, fuzzy_res4)
    print(result[0] + "," + result[1] + "," + result[2] + "," + result[3] + "," + result[4])

    # f = open("Assets/Scripts/PythonScripts/results.txt", "w")
    # for i in range(0, 11):
    #     for j in range(0, 11):
    #         for k in range(0, 11):
    #             res = insert_neuro_values4(i/10, j/10, k/10)
    #             f.write(f"{i/10},{j/10},{k/10};{simulate_system(res[0], res[1], res[2], res[3])}\n")
    # f.close()
