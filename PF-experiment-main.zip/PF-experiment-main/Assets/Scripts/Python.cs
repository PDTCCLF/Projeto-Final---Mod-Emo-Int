using System.Diagnostics;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class Python
{
    public static string ExecutePythonScript(string script, string input)
    {
        // Specify the path to your Python script
        string pythonScriptPath = "C:/Users/SAMSUNG/Desktop/PF/future-falls-main/future-falls-main/Assets/Scripts/PythonScripts/" + script + ".py";

        // Create a process to run the Python interpreter
        ProcessStartInfo startInfo = new ProcessStartInfo
        {
            FileName = "C:/Users/SAMSUNG/AppData/Local/Microsoft/WindowsApps/python.exe",
            Arguments = pythonScriptPath + " \"" + input + "\"",
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true,
        };

        using (Process process = new Process { StartInfo = startInfo })
        {
            // Start the process
            process.Start();

            // Read the output and error streams
            // int output = Convert.ToInt32(process.StandardOutput.ReadToEnd());
            string output = process.StandardOutput.ReadToEnd();
            string error = process.StandardError.ReadToEnd();

            // Wait for the process to exit
            process.WaitForExit();

            // Display the output and error
            UnityEngine.Debug.Log("Output:");
            UnityEngine.Debug.Log(output);

            UnityEngine.Debug.Log("Error:");
            UnityEngine.Debug.Log(error);

            return output;
        }
        
    }
}
