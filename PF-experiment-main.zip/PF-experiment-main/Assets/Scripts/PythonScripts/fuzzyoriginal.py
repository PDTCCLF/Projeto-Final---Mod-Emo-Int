import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl
import random
import sys

values = sys.argv[1].split(',')
ser_val = float(values[0])
nor_val = float(values[1])
dop_val = float(values[2])

x = np.arange(0, 1, 0.001)
y = np.arange(0, 1, 0.001)
z = np.arange(0, 1, 0.001)
loveheim_range = np.arange(0, 9, 0.01)

serotonin = ctrl.Antecedent(x, 'serotonin')
noradrenaline = ctrl.Antecedent(y, 'noradrenaline')
dopamine = ctrl.Antecedent(z, 'dopamine')

serotonin['low'] = fuzz.trimf(x, [0, 0, 1])
serotonin['high'] = fuzz.trimf(x, [0, 1, 1])

noradrenaline['low'] = fuzz.trimf(y, [0, 0, 1])
noradrenaline['high'] = fuzz.trimf(y, [0, 1, 1])

dopamine['low'] = fuzz.trimf(z, [0, 0, 1])
dopamine['high'] = fuzz.trimf(z, [0, 1, 1])

# serotonin.view()
# noradrenaline.view()
# dopamine.view()

emotion = ctrl.Consequent(loveheim_range, 'emotion')

emotion['Shame/Humiliation'] = fuzz.trimf(loveheim_range, [0, 0, 4])
emotion['Fear/Terror'] = fuzz.trimf(loveheim_range, [1, 2, 3])
emotion['Distress/Anguish'] = fuzz.trimf(loveheim_range, [2, 3, 4])
emotion['Contempt/Disgust'] = fuzz.trimf(loveheim_range, [3, 4, 5])
emotion['Enjoyment/Joy'] = fuzz.trimf(loveheim_range, [4, 5, 6])
emotion['Anger/Rage'] = fuzz.trimf(loveheim_range, [5, 6, 7])
emotion['Surprise'] = fuzz.trimf(loveheim_range, [6, 7, 8])
emotion['Interest/Excitement'] = fuzz.trimf(loveheim_range, [5, 9, 9])

rule1 = ctrl.Rule(serotonin['high'] & noradrenaline['high'] & dopamine['high'], emotion['Interest/Excitement'])
rule2 = ctrl.Rule(serotonin['low'] & noradrenaline['high'] & dopamine['high'], emotion['Anger/Rage'])
rule3 = ctrl.Rule(serotonin['low'] & noradrenaline['high'] & dopamine['low'], emotion['Distress/Anguish'])
rule4 = ctrl.Rule(serotonin['high'] & noradrenaline['high'] & dopamine['low'], emotion['Surprise'])
rule5 = ctrl.Rule(serotonin['high'] & noradrenaline['low'] & dopamine['high'], emotion['Enjoyment/Joy'])
rule6 = ctrl.Rule(serotonin['low'] & noradrenaline['low'] & dopamine['high'], emotion['Fear/Terror'])
rule7 = ctrl.Rule(serotonin['low'] & noradrenaline['low'] & dopamine['low'], emotion['Shame/Humiliation'])
rule8 = ctrl.Rule(serotonin['high'] & noradrenaline['low'] & dopamine['low'], emotion['Contempt/Disgust'])

emotion_ctrl = ctrl.ControlSystem([rule1, rule2, rule3, rule4, rule5, rule6, rule7, rule8])

emotion_simulation = ctrl.ControlSystemSimulation(emotion_ctrl)

def calculate_output1(ser_val, nor_val, dop_val):
  emotion_simulation.input['serotonin'] = ser_val
  emotion_simulation.input['noradrenaline'] = nor_val
  emotion_simulation.input['dopamine'] = dop_val

  emotion_simulation.compute()

  memberships = {}

  memberships['Interest/Excitement'] = fuzz.interp_membership(loveheim_range, emotion['Interest/Excitement'].mf, emotion_simulation.output['emotion'])
  memberships['Anger/Rage'] = fuzz.interp_membership(loveheim_range, emotion['Anger/Rage'].mf, emotion_simulation.output['emotion'])
  memberships['Distress/Anguish'] = fuzz.interp_membership(loveheim_range, emotion['Distress/Anguish'].mf, emotion_simulation.output['emotion'])
  memberships['Surprise'] = fuzz.interp_membership(loveheim_range, emotion['Surprise'].mf, emotion_simulation.output['emotion'])
  memberships['Enjoyment/Joy'] = fuzz.interp_membership(loveheim_range, emotion['Enjoyment/Joy'].mf, emotion_simulation.output['emotion'])
  memberships['Fear/Terror'] = fuzz.interp_membership(loveheim_range, emotion['Fear/Terror'].mf, emotion_simulation.output['emotion'])
  memberships['Shame/Humiliation'] = fuzz.interp_membership(loveheim_range, emotion['Shame/Humiliation'].mf, emotion_simulation.output['emotion'])
  memberships['Contempt/Disgust'] = fuzz.interp_membership(loveheim_range, emotion['Contempt/Disgust'].mf, emotion_simulation.output['emotion'])
  return memberships

def insert_neuro_values1(ser_val, nor_val, dop_val):
  memberships = calculate_output1(ser_val, nor_val, dop_val)
  max_val = max(memberships, key=memberships.get)
  return(max_val)

# insert_neuro_values1(ser_val, nor_val, dop_val)

f = open("Assets/Scripts/PythonScripts/results.txt", "w")
for i in range(0, 11):
    for j in range(0, 11):
        for k in range(0, 11):
            f.write(f"{i/10},{j/10},{k/10};{insert_neuro_values1(i/10, j/10, k/10)}\n")
f.close()